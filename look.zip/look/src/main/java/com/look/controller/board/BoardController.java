package com.look.controller.board;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.look.model.board.BoardService;
import com.look.model.board.BoardVO;
import com.look.model.member.MemberVO;

@Controller
public class BoardController {

	@Autowired
	BoardService boardservice;

	// 기본 (로그인 페이지)
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String main() {

		return "index";

	}

	// 메인 페이지
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String tomain() {

		return "board/main";

	}

	// 입력 페이지
	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public String end() {

		return "board/insert";

	}

	// ajax insert 주소
	@RequestMapping("/end")
	public String insert(BoardVO vo, MemberVO mvo, HttpSession session) {
		MemberVO member = (MemberVO) session.getAttribute("member");
		String member_id = member.getMember_id();

		vo.setWriter(member_id);
		boardservice.insertBoard(vo);
		System.out.println("데이터 추가 성공!!!");

		return "redirect:main";

	}

	// 게시판 리스트 페이지
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) {
		model.addAttribute("list", boardservice.boardList());

		return "board/list";
	}

	// 상세 페이지
	@RequestMapping("/Detail")
	public String Detail(int seq, Model model) {
		BoardVO boardVO = boardservice.getBoardList(seq);
		model.addAttribute("detail", boardVO);

		return "board/detail";
	}

	// 글 삭제
	@RequestMapping("/delete")
	public String delete(int seq) {
		boardservice.deleteBoard(seq);
		System.out.print("삭제완료.!!");

		return "redirect:list";

	}

	// 글 수정 페이지
	@RequestMapping("/updatepage")
	public String updatepage(int seq, Model model) {
		BoardVO board = boardservice.getBoardList(seq);
		model.addAttribute("update", board);

		return "board/update";
	}

	// 글 수정
	@RequestMapping("/update")
	public String update(BoardVO vo) {

		boardservice.updateBoard(vo);
		return "board/detail";
	}

}