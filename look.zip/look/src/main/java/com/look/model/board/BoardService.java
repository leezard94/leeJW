package com.look.model.board;

import java.util.List;

public interface BoardService {
	
	//입력
	void insertBoard(BoardVO vo);
	
	//리스트 
	public List<BoardVO> boardList();
	
	//상세페이지 
	public BoardVO  getBoardList(int seq);
	
	//글 삭제
	public int deleteBoard(int seq);
	
	//글 수정
	public void updateBoard(BoardVO vo);
	

}
