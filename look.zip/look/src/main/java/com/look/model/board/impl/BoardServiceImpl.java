package com.look.model.board.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.look.model.board.BoardService;
import com.look.model.board.BoardVO;

@Service("boardservice")
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDAO boardDAO;

	//입력
	@Override
	public void insertBoard(BoardVO vo) {
		boardDAO.insertBoard(vo);
	}
	
	//리스트 
	@Override
	public List<BoardVO> boardList() {
		return boardDAO.boardList();
	}
	
	//상세페이지 
	@Override
	public BoardVO  getBoardList(int seq) {
		return boardDAO.getBoardList(seq);
	}
	//글 삭제
	@Override
	public int deleteBoard(int seq) {
		return boardDAO.deleteBoard(seq);
	}
	
	//글 수정
	public void updateBoard(BoardVO vo) {
		boardDAO.updateBoard(vo);
	}
	

}
