package com.look.model.board.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.look.model.board.BoardVO;

@Repository
public class BoardDAO {

	@Autowired
	SqlSession sqlsession;


	//내용입력
	public void insertBoard(BoardVO vo) {
		sqlsession.insert("BoardDAO.insertBoard", vo);

	}

	//리스트
	public List<BoardVO> boardList() {
		List<BoardVO> result = sqlsession.selectList("BoardDAO.Boardlist");
		return result;
	}
	
	//상세페이지
	public BoardVO  getBoardList(int seq) {
		BoardVO result = sqlsession.selectOne("BoardDAO.getBoardList",seq);
		return result;
	}
	
	//글 삭제
	public int deleteBoard(int seq) {
		int resutl = sqlsession.delete("BoardDAO.deleteBoard",seq);
		return resutl;
	}
	
	//글 수정
	public void updateBoard(BoardVO vo) {
		sqlsession.update("BoardDAO.updateBoard",vo);
	}
	
	

}
